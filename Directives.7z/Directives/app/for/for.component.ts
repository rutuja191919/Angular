import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for',
  templateUrl: './for.component.html',
  styleUrls: ['./for.component.css']
})
export class ForComponent 
{
 public Batches = ["PPA","LB","Angular","Python","LSP"];
}
