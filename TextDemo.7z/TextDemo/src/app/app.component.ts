import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<h1 class = "marvellous"> Marvellous Infosystems </h1> <input type = "text">',
  styles: ['.marvellous { color : blue }']
})
export class AppComponent {
  title = 'Marvellous';
}
