export interface IBatch
{
  name : string,
  duration : number
}
